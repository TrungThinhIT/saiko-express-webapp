<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class tinhthanh extends Model
{
    //
    protected $table = 'VNPOST_TinhThanh';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
