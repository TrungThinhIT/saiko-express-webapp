<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Nhap_Kho extends Model
{
    //
}
