<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TimelineTrack extends Model
{
    protected $table = 'timelinetrack';
    protected $primaryKey = 'Id';
    public $timestamps = false;
}
