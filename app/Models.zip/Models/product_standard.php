<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class product_standard extends Model
{
    protected $table = 'product_standard';
    protected $primaryKey = 'jan_code';
    public $timestamps = false;
}
