<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tracking_User extends Model
{
    protected $table = 'tracking_user';
    protected $primaryKey = 'Id';
    public $timestamps = false;
}
