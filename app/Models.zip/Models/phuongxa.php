<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class phuongxa extends Model
{
    //
    protected $table = 'VNPOST_PhuongXa';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
