<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class quanhuyen extends Model
{
    //
    protected $table = 'VNPOST_QuanHuyen';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
