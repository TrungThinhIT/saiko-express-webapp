<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WH_SKU_Item extends Model
{
    protected $table = 'wh_sku_item';
    protected $primaryKey = 'Id';
    public $timestamps = false;
}
